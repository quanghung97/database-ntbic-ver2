<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cong_trinh_nghien_cuu extends Model
{
    protected $table = 'cong_trinh_nghien_cuu';
    public $timestamps = false;
}
