<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class chuyen_nganh_khcn extends Model
{
    protected $table = 'chuyen_nganh_khcn';
    public $timestamps = false;
}
