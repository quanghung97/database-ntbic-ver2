<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class chuyen_gia_khcn extends Model
{
    protected $table = 'chuyen_gia_khcn';
    public $timestamps = false;
}
