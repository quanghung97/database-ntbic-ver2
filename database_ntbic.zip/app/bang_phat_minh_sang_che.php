<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bang_phat_minh_sang_che extends Model
{
    protected $table = 'bang_phat_minh_sang_che';
    public $timestamps = false;
}
